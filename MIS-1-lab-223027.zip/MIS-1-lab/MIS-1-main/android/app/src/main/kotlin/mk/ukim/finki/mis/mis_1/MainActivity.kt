package mk.ukim.finki.mis.mis_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
