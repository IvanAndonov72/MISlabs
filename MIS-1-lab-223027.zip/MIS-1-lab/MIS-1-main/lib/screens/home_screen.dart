import 'package:flutter/material.dart';
import '../models/exam.dart';
import '../widgets/exam_card.dart';

class HomeScreen extends StatelessWidget {
  final String indexNumber;

  const HomeScreen({super.key, required this.indexNumber});

  @override
  Widget build(BuildContext context) {
    // Hardcoded exams
    final List<Exam> exams = [
      Exam(
          subjectName: "Mathematics 1",
          dateTime: DateTime(2025, 12, 15, 9, 0),
          rooms: ["101", "102"]),
      Exam(
          subjectName: "Physics 1",
          dateTime: DateTime(2025, 12, 17, 14, 0),
          rooms: ["201"]),
      Exam(
          subjectName: "Chemistry",
          dateTime: DateTime(2025, 12, 20, 11, 0),
          rooms: ["103"]),
      Exam(
          subjectName: "Biology",
          dateTime: DateTime(2025, 11, 10, 10, 0),
          rooms: ["105", "106"]),
      Exam(
          subjectName: "Computer Science",
          dateTime: DateTime(2025, 12, 25, 13, 0),
          rooms: ["301"]),
      Exam(
          subjectName: "English",
          dateTime: DateTime(2025, 12, 28, 9, 30),
          rooms: ["401"]),
      Exam(
          subjectName: "History",
          dateTime: DateTime(2026, 1, 2, 12, 0),
          rooms: ["201", "202"]),
      Exam(
          subjectName: "Geography",
          dateTime: DateTime(2026, 1, 4, 15, 0),
          rooms: ["103"]),
      Exam(
          subjectName: "Philosophy",
          dateTime: DateTime(2026, 1, 6, 10, 0),
          rooms: ["105"]),
      Exam(
          subjectName: "Economics",
          dateTime: DateTime(2026, 1, 8, 14, 0),
          rooms: ["301"]),
    ];

    // Sort by date
    exams.sort((a, b) => a.dateTime.compareTo(b.dateTime));

    return Scaffold(
      appBar: AppBar(
        title: Text("Распоред за испити - $indexNumber"),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: exams.length,
              itemBuilder: (context, index) {
                return ExamCard(exam: exams[index]);
              },
            ),
          ),
          Container(
            color: Colors.blueGrey[50],
            padding: const EdgeInsets.all(16),
            child: Text(
              "Вкупно испити: ${exams.length}",
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ),
        ],
      ),
    );
  }
}
